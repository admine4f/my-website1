// =========================================================================
// TADS.me integration (Text-Graphic Block, widget type "static") - plays INSIDE the Telegram Mini App.
// Official API: https://docs.tads.me (script https://w.tads.me/widget.js, window.tads.init(...),
// container <div id="tads-container-WIDGET_ID">, controller.loadAd() -> controller.showAd()).
//
// A Text-Graphic Block is a static ad (not a video), so the ad network gives no "finished" event.
// Rule used here: the reward is granted ONLY after the TADS block was really displayed
// (onShowReward / showAd resolved) AND stayed on screen for TADS_HOLD_SECONDS (countdown shown to the user).
// No ad shown / no ad found = NO reward.
// =========================================================================

export const TADS_HOLD_SECONDS = 30;
export const TADS_DEFAULT_WIDGET_ID = '12823';

/** TADS widget ids are 5-digit numbers starting with 12 (e.g. 12823). Monetag (8 digits) / RichAds (6) / OnClickA (letters) never match. */
export function isTadsAd(id?: string | number | null): boolean {
  const s = String(id ?? '').trim();
  return s === TADS_DEFAULT_WIDGET_ID || /^12\d{3}$/.test(s);
}

const controllers: Record<string, any> = {};
let handlers: { onShow?: () => void; onNotFound?: () => void } = {};

function waitFor(test: () => boolean, timeoutMs: number): Promise<boolean> {
  return new Promise((resolve) => {
    if (test()) return resolve(true);
    const start = Date.now();
    const iv = setInterval(() => {
      if (test()) { clearInterval(iv); resolve(true); }
      else if (Date.now() - start > timeoutMs) { clearInterval(iv); resolve(false); }
    }, 50);
  });
}

function ensureTadsScript(): Promise<boolean> {
  const w = window as any;
  if (w.tads && typeof w.tads.init === 'function') return Promise.resolve(true);
  if (!document.querySelector('script[src*="w.tads.me/widget.js"]')) {
    const s = document.createElement('script');
    s.src = 'https://w.tads.me/widget.js';
    s.async = true;
    document.head.appendChild(s);
  }
  return waitFor(() => !!(w.tads && typeof w.tads.init === 'function'), 8000);
}

function getController(widgetId: string): any {
  if (controllers[widgetId]) return controllers[widgetId];
  const w = window as any;
  const ctrl = w.tads.init({
    widgetId: Number(widgetId),
    type: 'static',
    debug: false, // production: real ads
    onShowReward: () => { handlers.onShow && handlers.onShow(); },
    // Click reward is intentionally NOT used: a click would leave the app. Our reward = ad displayed + hold time.
    onClickReward: () => {},
    onAdsNotFound: () => { handlers.onNotFound && handlers.onNotFound(); },
  });
  controllers[widgetId] = ctrl;
  return ctrl;
}

function emitCountdown(left: number | null, total: number) {
  try { window.dispatchEvent(new CustomEvent('tads-countdown', { detail: { left, total } })); } catch {}
}

/**
 * Show the TADS block inside <div id="tads-container-WIDGET_ID"> (rendered by the ad modal) and resolve TRUE only
 * when the ad was really displayed and stayed for `holdSeconds`. Resolves FALSE for: script missing, no ads, error.
 */
export function playTadsBlock(widgetId: string, holdSeconds: number = TADS_HOLD_SECONDS): Promise<boolean> {
  return new Promise<boolean>((resolve) => {
    let finished = false;
    let shown = false;
    let timer: any = null;
    let safety: any = null;

    const finish = (ok: boolean) => {
      if (finished) return;
      finished = true;
      if (timer) clearInterval(timer);
      if (safety) clearTimeout(safety);
      handlers = {};
      emitCountdown(null, holdSeconds);
      resolve(ok);
    };

    const startHold = () => {
      if (shown || finished) return;
      shown = true;
      if (safety) clearTimeout(safety);
      let left = holdSeconds;
      emitCountdown(left, holdSeconds);
      timer = setInterval(() => {
        if (document.hidden) return; // count only while the user is really looking at the app
        left -= 1;
        emitCountdown(Math.max(0, left), holdSeconds);
        if (left <= 0) finish(true);
      }, 1000);
    };

    // Safety: if nothing was displayed within 20s, treat as "no ad"
    safety = setTimeout(() => { if (!shown) finish(false); }, 20000);

    (async () => {
      try {
        if (!(await ensureTadsScript())) return finish(false);
        const id = String(widgetId).trim();
        const found = await waitFor(() => !!document.getElementById(`tads-container-${id}`), 4000);
        if (!found) return finish(false);
        const container = document.getElementById(`tads-container-${id}`) as HTMLElement;
        container.innerHTML = '';

        handlers = { onShow: startHold, onNotFound: () => finish(false) };
        const ctrl = getController(id);
        await ctrl.loadAd();
        await ctrl.showAd();

        // showAd resolved: make sure a block really rendered before counting the hold time
        if (!finished && !shown) {
          const rendered = await waitFor(() => container.childElementCount > 0 || !!(container.textContent || '').trim(), 3000);
          if (rendered) startHold(); else finish(false);
        }
      } catch (e) {
        console.warn('[TADS] failed:', e);
        finish(false);
      }
    })();
  });
}

/** Compatibility wrapper used by adWaterfall.ts */
export async function showTadsAdByContext(widgetId: string, _actionType?: string, _targetId?: number): Promise<boolean> {
  return playTadsBlock(String(widgetId));
}
